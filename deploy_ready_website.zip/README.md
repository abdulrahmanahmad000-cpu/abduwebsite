# Deploy Ready Website

This folder contains a single-page website ready for GitHub Pages or any static host.

## Files
- `index.html`

## Publish on GitHub Pages
1. Create a new GitHub repository
2. Upload `index.html`
3. In repository settings, enable GitHub Pages from the main branch
4. Your site will get a public link
